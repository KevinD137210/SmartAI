
import React, { useState, useRef } from 'react';
import { Search, Loader2, Tag, Sparkles, Globe, ChevronDown, Camera, ShoppingBag, ArrowRight, TrendingUp, TrendingDown, Minus, Upload, Image as ImageIcon, MapPin, Hammer, Car, Home, HardHat, FileText, AlertTriangle, ClipboardList, BookOpen } from 'lucide-react';
import { getMarketValuation, analyzeItemFromImage } from '../services/geminiService';
import { PriceCheckResult } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

export const PriceCheck: React.FC = () => {
  const { t, language } = useLanguage();
  const [query, setQuery] = useState('');
  const [scope, setScope] = useState(''); // Formerly condition
  const [locationStr, setLocationStr] = useState('');
  const [category, setCategory] = useState('Construction');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'IDLE' | 'ANALYZING_IMAGE' | 'VALUATION_SEARCH'>('IDLE');
  const [result, setResult] = useState<PriceCheckResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  
  // Default to US unless language is strictly TW
  const [targetLocale, setTargetLocale] = useState(language === 'zh-TW' ? 'zh-TW' : 'en-US');

  const CATEGORIES = [
      { id: 'Construction', icon: Home, label: t('price.cat.construction') || 'Residential' },
      { id: 'Commercial', icon: HardHat, label: t('price.cat.commercial') || 'Commercial' },
      { id: 'Auto', icon: Car, label: t('price.cat.auto') || 'Auto Body' },
      { id: 'General', icon: Hammer, label: t('price.cat.general') || 'General' },
  ];

  const handleValuation = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;

    setStep('VALUATION_SEARCH');
    setLoading(true);
    setResult(null);

    // Combine category into query for better context
    const fullQuery = `[${category}] ${query}`;
    const data = await getMarketValuation(fullQuery, scope, targetLocale, locationStr);
    setResult(data);
    setLoading(false);
    setStep('IDLE');
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => setUploadedImage(e.target?.result as string);
    reader.readAsDataURL(file);

    setStep('ANALYZING_IMAGE');
    setLoading(true);
    setResult(null);
    setQuery(''); 

    try {
        const analysis = await analyzeItemFromImage(file, targetLocale);
        if (analysis.name) {
            setQuery(analysis.name);
            setScope(analysis.condition);
            if(analysis.category.includes("Auto")) setCategory('Auto');
            else setCategory('Construction');
        } else {
            alert(t('price.identifyFail'));
        }
    } catch (error) {
        console.error("Image identification failed", error);
    } finally {
        setLoading(false);
        setStep('IDLE');
        if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const LOCALE_OPTIONS = [
      { code: 'en-US', label: 'USA', flag: '🇺🇸' },
      { code: 'zh-TW', label: 'Taiwan', flag: '🇹🇼' },
      { code: 'ja-JP', label: 'Japan', flag: '🇯🇵' },
      { code: 'ko-KR', label: 'Korea', flag: '🇰🇷' },
      { code: 'en-EU', label: 'Europe', flag: '🇪🇺' },
      { code: 'zh-CN', label: 'China', flag: '🇨🇳' },
  ];

  return (
    <div className="max-w-6xl mx-auto animate-fadeIn pb-20">
      
      {/* Header Area */}
      <div className="text-center mb-10 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full text-sm font-bold border border-indigo-100 dark:border-indigo-800">
              <Sparkles size={16} />
              {t('price.aiPowered')}
          </div>
          <h1 className="text-4xl md:text-5xl font-orbitron font-bold text-slate-900 dark:text-white">
              {t('price.mainTitle')}
          </h1>
          <p className="text-slate-500 dark:text-slate-400 max-w-xl mx-auto text-lg">
              {t('price.mainSubtitle')}
          </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Panel: Input Form */}
          <div className="lg:col-span-5 space-y-6">
              <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-xl shadow-slate-200/50 dark:shadow-black/20 border border-slate-100 dark:border-slate-800 relative overflow-hidden">
                  
                  {/* Photo Upload Area - Resized to normal height (h-48) */}
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className={`relative w-full h-48 rounded-3xl border-2 border-dashed transition-all cursor-pointer overflow-hidden group flex flex-col items-center justify-center ${uploadedImage ? 'border-indigo-500 dark:border-indigo-400' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-600 hover:bg-slate-50 dark:hover:bg-slate-800/50'}`}
                  >
                      {uploadedImage ? (
                          <>
                            <img src={uploadedImage} alt="Item" className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <Camera className="text-white" size={40} />
                            </div>
                          </>
                      ) : (
                          <div className="flex flex-col items-center gap-2 p-6 text-center">
                              <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 group-hover:scale-110 transition-transform">
                                  <ImageIcon size={24} />
                              </div>
                              <div>
                                  <h3 className="font-bold text-slate-800 dark:text-white text-base">{t('price.uploadPhoto')}</h3>
                                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">{t('price.uploadDesc')}</p>
                              </div>
                          </div>
                      )}
                      
                      {step === 'ANALYZING_IMAGE' && (
                          <div className="absolute inset-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm flex flex-col items-center justify-center z-10">
                              <Loader2 className="animate-spin text-indigo-600 mb-2" size={32} />
                              <span className="font-bold text-indigo-900 dark:text-indigo-300 text-sm animate-pulse">{t('price.identifying')}</span>
                          </div>
                      )}
                  </div>
                  <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handleImageUpload} />

                  {/* Form */}
                  <form onSubmit={handleValuation} className="mt-6 space-y-4">
                      
                      {/* Category Selector - Enlarged and labeled */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {CATEGORIES.map(cat => (
                              <button
                                key={cat.id}
                                type="button"
                                onClick={() => setCategory(cat.id)}
                                className={`flex flex-col items-center justify-center gap-2 py-4 rounded-2xl transition-all border ${
                                    category === cat.id 
                                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-md transform scale-105' 
                                    : 'bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-transparent hover:bg-slate-100 dark:hover:bg-slate-700'
                                }`}
                              >
                                  <cat.icon size={24} />
                                  <span className="text-xs font-bold">{cat.label}</span>
                              </button>
                          ))}
                      </div>

                      <div>
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 mb-1.5 block">{t('price.itemName')}</label>
                          <div className="relative">
                              <input
                                  type="text"
                                  value={query}
                                  onChange={(e) => setQuery(e.target.value)}
                                  placeholder={t('price.placeholder')}
                                  className="w-full pl-4 pr-10 py-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 dark:text-white font-medium"
                              />
                              <Hammer className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                          </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 mb-1.5 block">{t('price.location')}</label>
                              <div className="relative">
                                  <input 
                                      type="text" 
                                      value={locationStr}
                                      onChange={(e) => setLocationStr(e.target.value)}
                                      placeholder="City or Zip"
                                      className="w-full pl-4 pr-8 py-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 dark:text-white font-medium"
                                  />
                                  <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
                              </div>
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 mb-1.5 block">{t('set.language')}</label>
                              <div className="relative">
                                  <select
                                      value={targetLocale}
                                      onChange={(e) => setTargetLocale(e.target.value)}
                                      className="appearance-none w-full pl-4 pr-8 py-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 dark:text-white font-medium cursor-pointer"
                                  >
                                      {LOCALE_OPTIONS.map(opt => <option key={opt.code} value={opt.code}>{opt.flag} {opt.label}</option>)}
                                  </select>
                                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
                              </div>
                          </div>
                      </div>

                      <div>
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 mb-1.5 block">{t('price.scope')}</label>
                          <textarea
                              value={scope}
                              onChange={(e) => setScope(e.target.value)}
                              rows={2}
                              placeholder="Describe dimensions, materials, or extent of damage..."
                              className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 dark:text-white font-medium resize-none"
                          />
                      </div>

                      <button
                        type="submit"
                        disabled={loading || !query.trim()}
                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
                      >
                        {step === 'VALUATION_SEARCH' ? <Loader2 className="animate-spin" /> : <Sparkles size={20} />}
                        <span>{t('price.button')}</span>
                      </button>
                  </form>
              </div>
          </div>

          {/* Right Panel: Estimation Result */}
          <div className="lg:col-span-7">
              {loading && step === 'VALUATION_SEARCH' ? (
                  <div className="h-[500px] bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center p-8 text-center animate-pulse">
                      <div className="w-24 h-24 bg-indigo-50 dark:bg-indigo-900/20 rounded-full flex items-center justify-center mb-6">
                          <Globe className="text-indigo-600 dark:text-indigo-400 animate-spin-slow" size={40} />
                      </div>
                      <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">{t('price.checking')}</h3>
                      <p className="text-slate-500 max-w-xs">{t('price.marketSearch')}</p>
                  </div>
              ) : result ? (
                  <div className="space-y-6 animate-fadeIn">
                      
                      {/* Estimation Card */}
                      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-xl shadow-slate-200/50 dark:shadow-black/20 border border-slate-100 dark:border-slate-800 relative overflow-hidden">
                          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-bl-[10rem] pointer-events-none"></div>
                          
                          {/* Title Header */}
                          <div className="flex justify-between items-start mb-8 relative z-10">
                              <div>
                                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-bold uppercase tracking-wider mb-2">
                                      {category === 'Auto' ? <Car size={12} /> : <Home size={12} />} {category} Estimate
                                  </div>
                                  <h2 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-white leading-tight">
                                      {result.productName}
                                  </h2>
                              </div>
                              <div className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold ${
                                  result.marketTrend === 'High Demand' ? 'bg-rose-100 dark:bg-rose-900/30 text-rose-600' :
                                  'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                              }`}>
                                  {result.marketTrend === 'High Demand' && <TrendingUp size={16} />}
                                  {result.marketTrend}
                              </div>
                          </div>

                          {/* Grand Total */}
                          <div className="mb-8 text-center p-6 bg-slate-50 dark:bg-slate-950/50 rounded-3xl border border-slate-100 dark:border-slate-800">
                              <p className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-1">{t('price.estimatedTotal')}</p>
                              <div className="text-4xl md:text-5xl font-bold text-slate-800 dark:text-white tracking-tight">
                                  {result.currency} {result.valuation.min.toLocaleString()} - {result.valuation.max.toLocaleString()}
                              </div>
                              <p className="text-xs text-slate-400 mt-2">*{t('price.disclaimer')}</p>
                          </div>

                          {/* Cost Breakdown */}
                          {result.breakdown && (
                              <div className="grid grid-cols-2 gap-4 mb-8">
                                  <div className="p-4 bg-emerald-50/50 dark:bg-emerald-900/10 rounded-2xl border border-emerald-100 dark:border-emerald-900/20">
                                      <div className="flex items-center gap-2 mb-2 text-emerald-700 dark:text-emerald-400 font-bold">
                                          <ShoppingBag size={16} />
                                          <span>{t('price.materials')}</span>
                                      </div>
                                      <div className="text-lg font-bold text-slate-700 dark:text-slate-200">
                                          {result.currency} {result.breakdown.materials.low.toLocaleString()} - {result.breakdown.materials.high.toLocaleString()}
                                      </div>
                                  </div>
                                  <div className="p-4 bg-amber-50/50 dark:bg-amber-900/10 rounded-2xl border border-amber-100 dark:border-amber-900/20">
                                      <div className="flex items-center gap-2 mb-2 text-amber-700 dark:text-amber-400 font-bold">
                                          <Hammer size={16} />
                                          <span>{t('price.labor')}</span>
                                      </div>
                                      <div className="text-lg font-bold text-slate-700 dark:text-slate-200">
                                          {result.currency} {result.breakdown.labor.low.toLocaleString()} - {result.breakdown.labor.high.toLocaleString()}
                                      </div>
                                  </div>
                              </div>
                          )}

                          {/* Basic Scope */}
                          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 mb-6">
                              <h4 className="font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-2">
                                  <FileText size={16} className="text-indigo-500"/>
                                  {t('price.scope')}
                              </h4>
                              <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                                  {result.analysis}
                              </p>
                          </div>

                          {/* Detailed Assessment Section - NEW */}
                          {result.detailedAnalysis && (
                              <div className="space-y-4">
                                  <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                      <BookOpen size={20} className="text-indigo-500" />
                                      {t('price.professionalAssessment')}
                                  </h3>
                                  
                                  {/* Methodology */}
                                  <div className="bg-indigo-50 dark:bg-indigo-900/10 p-5 rounded-2xl border border-indigo-100 dark:border-indigo-900/20">
                                      <h4 className="font-bold text-indigo-800 dark:text-indigo-300 mb-2 flex items-center gap-2 text-sm uppercase tracking-wider">
                                          <ClipboardList size={16} /> {t('price.method')}
                                      </h4>
                                      <div className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed whitespace-pre-line">
                                          {result.detailedAnalysis.methodology}
                                      </div>
                                  </div>

                                  {/* Precautions & Routine Grid */}
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                      {/* Precautions */}
                                      <div className="bg-rose-50 dark:bg-rose-900/10 p-5 rounded-2xl border border-rose-100 dark:border-rose-900/20">
                                          <h4 className="font-bold text-rose-800 dark:text-rose-300 mb-2 flex items-center gap-2 text-sm uppercase tracking-wider">
                                              <AlertTriangle size={16} /> {t('price.precautions')}
                                          </h4>
                                          <div className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed whitespace-pre-line">
                                              {result.detailedAnalysis.precautions}
                                          </div>
                                      </div>

                                      {/* Routine */}
                                      <div className="bg-slate-50 dark:bg-slate-800/50 p-5 rounded-2xl border border-slate-100 dark:border-slate-800">
                                          <h4 className="font-bold text-slate-700 dark:text-slate-400 mb-2 flex items-center gap-2 text-sm uppercase tracking-wider">
                                              <BookOpen size={16} /> {t('price.routine')}
                                          </h4>
                                          <div className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed whitespace-pre-line">
                                              {result.detailedAnalysis.routine}
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          )}
                      </div>

                      {/* References */}
                      <div>
                          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 px-2">{t('price.comparables')}</h3>
                          <div className="space-y-3">
                              {result.listings.length > 0 ? (
                                  result.listings.map((item, idx) => (
                                      <div key={idx} className="flex items-center gap-4 p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-500/30 transition-all group">
                                          <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 shrink-0 font-bold">
                                              {idx + 1}
                                          </div>
                                          <div className="flex-1 min-w-0">
                                              <div className="flex items-center gap-2 mb-1">
                                                  <span className="text-[10px] font-bold uppercase bg-slate-100 dark:bg-slate-800 text-slate-500 px-2 py-0.5 rounded">
                                                      {item.merchant}
                                                  </span>
                                              </div>
                                              <h4 className="font-medium text-slate-800 dark:text-white truncate">{item.title}</h4>
                                          </div>
                                          <div className="text-right">
                                              <div className="font-bold text-indigo-600 dark:text-indigo-400">{item.price}</div>
                                              <a 
                                                  href={item.url} 
                                                  target="_blank" 
                                                  rel="noopener noreferrer" 
                                                  className="text-xs text-slate-400 hover:text-indigo-500 flex items-center justify-end gap-1 mt-1"
                                              >
                                                  {t('price.view')} <ArrowRight size={12} />
                                              </a>
                                          </div>
                                      </div>
                                  ))
                              ) : (
                                  <div className="text-center py-8 text-slate-400 text-sm">No specific sources found via search grounding.</div>
                              )}
                          </div>
                      </div>

                  </div>
              ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-12 opacity-50">
                      <div className="w-32 h-32 bg-slate-100 dark:bg-slate-900 rounded-full flex items-center justify-center mb-6">
                          <HardHat size={48} className="text-slate-300 dark:text-slate-700" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-2">{t('price.readyToAppraise')}</h3>
                      <p className="text-slate-500 max-w-sm">{t('price.instruction')}</p>
                  </div>
              )}
          </div>
      </div>
    </div>
  );
};