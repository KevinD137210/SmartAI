import { GoogleGenAI, Type } from "@google/genai";
import { PriceCheckResult, Invoice, DocumentType, Transaction, PriceItem } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const LOCALE_CONFIG: Record<string, { lang: string, currency: string, region: string }> = {
  'zh-TW': { lang: 'Traditional Chinese (Taiwan)', currency: 'TWD', region: 'Taiwan' },
  'en-US': { lang: 'English (US)', currency: 'USD', region: 'United States' },
  'ja-JP': { lang: 'Japanese', currency: 'JPY', region: 'Japan' },
  'ko-KR': { lang: 'Korean', currency: 'KRW', region: 'South Korea' },
  'zh-CN': { lang: 'Simplified Chinese', currency: 'CNY', region: 'China' },
  'en-EU': { lang: 'English (Europe)', currency: 'EUR', region: 'Europe' },
};

// Step 1: Analyze Image for Project Scope and Damage
export const analyzeItemFromImage = async (imageFile: File, targetLocale: string): Promise<{ name: string, condition: string, category: string }> => {
  try {
    const modelId = 'gemini-2.5-flash';
    const base64Data = await fileToBase64(imageFile);
    
    const prompt = `
      Act as a Construction Estimator and Insurance Adjuster.
      Analyze the image to identify the work required.
      
      1. Identify the specific task (e.g., "Rear Bumper Replacement", "Drywall Water Damage Repair", "Window Installation").
      2. Estimate rough dimensions or quantity based on visual cues (e.g., "Approx 10 sq ft", "Standard Sedan Bumper").
      3. Assess the condition/complexity (e.g., "Requires structural work", "Surface level only", "New installation").
      
      Return the result in: ${LOCALE_CONFIG[targetLocale]?.lang || 'English'}.
    `;

    const response = await ai.models.generateContent({
        model: modelId,
        contents: [
            {
                role: 'user',
                parts: [
                    { text: prompt },
                    { inlineData: { mimeType: imageFile.type, data: base64Data } }
                ]
            }
        ],
        config: { 
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "Technical name of the task" },
                    condition: { type: Type.STRING, description: "Scope details and dimensions" },
                    category: { type: Type.STRING, description: "Industry (Auto, Construction, Plumbing, etc)" }
                },
                required: ["name", "condition"]
            }
        }
    });

    const text = response.text;
    if (!text) throw new Error("No analysis result");
    return JSON.parse(text);
  } catch (error) {
    console.error("Image Analysis Error:", error);
    return { name: "", condition: "", category: "" };
  }
};

// Step 2: Perform Professional Estimation
export const getMarketValuation = async (query: string, condition: string, targetLocale: string, locationContext?: string): Promise<PriceCheckResult> => {
  try {
    const modelId = 'gemini-2.5-flash'; 
    const config = LOCALE_CONFIG[targetLocale] || LOCALE_CONFIG['en-US'];
    const location = locationContext || config.region;

    const prompt = `
    Role: Senior Quantity Surveyor / Construction Estimator.
    Task: Create a cost estimate and detailed execution plan for: "${query}".
    Scope/Dimensions: ${condition}.
    Location for Labor Rates: ${location}.
    Currency: ${config.currency}.

    Instructions:
    1. Search for CURRENT local labor rates for the specific trade (e.g., Carpenter, Mechanic, Plumber) in ${location}.
    2. Search for material costs for the required items.
    3. Calculate estimated Hours required.
    4. Provide a breakdown: Materials, Labor, and Total.
    5. Detail the standard Construction Method (step-by-step).
    6. List critical Precautions (safety, risks).
    7. Describe Routine Construction details (standard practices).

    CRITICAL OUTPUT FORMAT (Strict Text Template):
    ---ESTIMATE_START---
    PROJECT: [Technical Project Title]
    CURRENCY: [Currency Code]
    TOTAL_LOW: [Number]
    TOTAL_HIGH: [Number]
    TOTAL_AVG: [Number]
    
    MAT_LOW: [Number]
    MAT_HIGH: [Number]
    
    LABOR_LOW: [Number]
    LABOR_HIGH: [Number]
    
    DEMAND: [High/Stable/Low]
    SCOPE: [Brief scope summary]
    
    ---DETAILS_START---
    METHOD: [Detailed step-by-step construction/repair method. Use bullet points.]
    PRECAUTIONS: [Safety warnings, risks, and necessary protections.]
    ROUTINE: [Standard industry practices, time required, and quality standards.]
    
    ---SOURCES_START---
    * [Source Name](URL) | [Item/Service] | [Price/Rate]
    * [Source Name](URL) | [Item/Service] | [Price/Rate]
    ---END---
    `;

    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.2, 
      },
    });

    const text = response.text || "";
    
    const result: PriceCheckResult = {
        productName: query,
        currency: config.currency,
        valuation: { min: 0, max: 0, avg: 0 },
        breakdown: {
            materials: { low: 0, high: 0 },
            labor: { low: 0, high: 0 },
            equipment: { low: 0, high: 0 },
            overhead: { low: 0, high: 0 }
        },
        marketTrend: 'Stable',
        analysis: "Estimation based on standard industry rates.",
        detailedAnalysis: {
            methodology: "",
            precautions: "",
            routine: ""
        },
        listings: [],
        sources: []
    };

    // Extract Fields Helper
    const extract = (key: string, section?: string) => {
        const regex = new RegExp(`${key}:\\s*([\\s\\S]*?)(?=(?:${section ? '---' : '\n[A-Z]+:'}|\n$))`, 'i');
        const match = text.match(regex);
        return match ? match[1].trim() : '';
    };
    
    const extractNum = (key: string) => {
        const match = text.match(new RegExp(`${key}:\\s*([\\d,.]+)`));
        if (match) return parseFloat(match[1].replace(/,/g, ''));
        return 0;
    };

    result.productName = extract('PROJECT') || query;
    result.currency = extract('CURRENCY') || config.currency;
    
    result.valuation.min = extractNum('TOTAL_LOW');
    result.valuation.max = extractNum('TOTAL_HIGH');
    result.valuation.avg = extractNum('TOTAL_AVG') || (result.valuation.min + result.valuation.max) / 2;

    if (result.breakdown) {
        result.breakdown.materials.low = extractNum('MAT_LOW');
        result.breakdown.materials.high = extractNum('MAT_HIGH');
        result.breakdown.labor.low = extractNum('LABOR_LOW');
        result.breakdown.labor.high = extractNum('LABOR_HIGH');
    }

    const demand = extract('DEMAND');
    if (demand.includes('High')) result.marketTrend = 'High Demand';
    else if (demand.includes('Low')) result.marketTrend = 'Low Demand';

    result.analysis = extract('SCOPE');

    // Extract Detailed Analysis
    if (result.detailedAnalysis) {
        result.detailedAnalysis.methodology = extract('METHOD', 'PRECAUTIONS');
        result.detailedAnalysis.precautions = extract('PRECAUTIONS', 'ROUTINE');
        result.detailedAnalysis.routine = extract('ROUTINE', '---SOURCES_START---');
    }

    // Parse Sources
    const sourcesSection = text.split('---SOURCES_START---')[1]?.split('---END---')[0];
    if (sourcesSection) {
        const regex = /^\s*[\*\-]?\s*\[([^\]]+)\]\(([^)]+)\)\s*(?:\||:|-)\s*(.+?)\s*(?:\||:|-)\s*(.+)$/gm;
        let match;
        while ((match = regex.exec(sourcesSection)) !== null) {
            result.listings.push({
                merchant: match[1].trim(),
                url: match[2].trim(),
                title: match[3].trim(),
                price: match[4].trim()
            });
        }
    }

    // Extract Grounding Sources
    if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
      response.candidates[0].groundingMetadata.groundingChunks.forEach((chunk: any) => {
        if (chunk.web) {
          result.sources.push({
            title: chunk.web.title || "Reference",
            uri: chunk.web.uri,
          });
        }
      });
    }

    result.sources = result.sources.filter((v, i, a) => a.findIndex(t => (t.uri === v.uri)) === i).slice(0, 10);

    return result;

  } catch (error) {
    console.error("Gemini Estimation Error:", error);
    return {
      productName: query,
      currency: "USD",
      valuation: { min: 0, max: 0, avg: 0 },
      marketTrend: 'Unknown',
      analysis: "Unable to generate estimate at this time.",
      listings: [],
      sources: []
    };
  }
};

// Helper
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            resolve(result.split(',')[1]); 
        };
        reader.onerror = error => reject(error);
    });
};

export const translateText = async (text: string, targetLocale: string): Promise<string> => {
    try {
        const modelId = 'gemini-2.5-flash';
        const config = LOCALE_CONFIG[targetLocale] || LOCALE_CONFIG['en-US'];
        
        const prompt = `Translate the following text to ${config.lang}. Keep technical terms or product names in original if commonly used. Text: "${text}"`;

        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
        });

        return response.text?.trim() || text;
    } catch (error) {
        return text;
    }
};

export const generateInvoiceEmail = async (invoice: Invoice, tone: 'professional' | 'friendly' | 'urgent', language: 'en' | 'zh-TW'): Promise<{ subject: string; body: string }> => {
  try {
    const modelId = 'gemini-2.5-flash';
    const typeStr = invoice.type === DocumentType.INVOICE ? (language === 'zh-TW' ? '發票' : 'Invoice') : (language === 'zh-TW' ? '報價單' : 'Quotation');
    const actionStr = invoice.type === DocumentType.INVOICE ? (language === 'zh-TW' ? '付款' : 'payment') : (language === 'zh-TW' ? '審閱' : 'review');
    const langName = language === 'zh-TW' ? 'Traditional Chinese (Taiwan)' : 'English';

    const prompt = `
      Act as a professional business assistant. Write a short, clear email for ${typeStr} #${invoice.number}.
      
      Details:
      - Client Name: ${invoice.clientName}
      - Total Amount: $${invoice.total}
      - Due Date: ${invoice.dueDate}
      - Tone: ${tone} (professional, friendly, or urgent reminder)
      - Language: ${langName}

      The email should politely ask the client to review the attached ${typeStr} (PDF) and proceed with ${actionStr}.
    `;

    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: { 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING },
            body: { type: Type.STRING }
          },
          required: ["subject", "body"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Email Gen Error:", error);
    return {
      subject: `Regarding ${invoice.type} #${invoice.number}`,
      body: language === 'zh-TW' 
        ? "抱歉，AI 無法產生郵件內容。請手動撰寫。" 
        : "Sorry, AI could not generate the email content. Please write manually."
    };
  }
};

export const generateTermsAndConditions = async (docLanguage: string, docType: string, userAddress?: string): Promise<string> => {
  try {
    const modelId = 'gemini-2.5-flash';
    const typeStr = docType === DocumentType.INVOICE ? 'Invoice' : 'Quotation';
    
    const prompt = `
    Generate concise standard terms and conditions for a business ${typeStr}.
    Context: User Address: "${userAddress || 'International'}". Language: ${docLanguage}.
    Include Payment Terms, Validity, and Liability. Format as bullet points.
    `;

    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: { temperature: 0.4 },
    });

    return response.text?.trim() || "Could not generate terms at this time.";
  } catch (error) {
    return "Error generating terms. Please try again.";
  }
};

export const analyzeReceipt = async (imageFile: File): Promise<Partial<Transaction>> => {
  try {
    const modelId = 'gemini-2.5-flash';
    const base64Data = await fileToBase64(imageFile);

    const prompt = `
    Analyze this receipt image. Extract data into the specified JSON structure.
    
    Rules:
    1. Field 'type' should be 'EXPENSE'.
    2. Field 'date' MUST be in 'YYYY-MM-DD' format. If unsure of year, use current year.
    3. Field 'amount' must be a number.
    4. Summarize items into a string.
    `;

    const response = await ai.models.generateContent({
        model: modelId,
        contents: [
            {
                role: 'user',
                parts: [
                    { text: prompt },
                    { inlineData: { mimeType: imageFile.type, data: base64Data } }
                ]
            }
        ],
        config: { 
            systemInstruction: "You are an expert financial accountant data entry specialist.",
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    amount: { type: Type.NUMBER },
                    date: { type: Type.STRING },
                    merchant: { type: Type.STRING },
                    items: { type: Type.STRING },
                    location: { type: Type.STRING },
                    category: { type: Type.STRING },
                    type: { type: Type.STRING }
                },
                required: ["amount", "date"]
            }
        }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Receipt Analysis Error:", error);
    return {};
  }
};