
export enum TransactionType {
  INCOME = 'INCOME',
  EXPENSE = 'EXPENSE'
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: TransactionType;
  category: string;
  // New fields for detailed tracking
  merchant?: string;
  items?: string;
  location?: string;
  projectId?: string; // Link expense to a project
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  notes?: string;
}

export enum InvoiceStatus {
  DRAFT = 'DRAFT',
  SENT = 'SENT',
  PAID = 'PAID'
}

export enum DocumentType {
  INVOICE = 'INVOICE',
  QUOTATION = 'QUOTATION'
}

export type ProjectStatus = 'NOT_SET' | 'QUOTE_SENT' | 'DEPOSIT_RECEIVED' | 'PROGRESS_PAYMENT' | 'COMPLETED' | 'ARCHIVED';

export interface Project {
  id: string;
  name: string;
  clientId: string;
  status: ProjectStatus;
  description?: string;
  createdAt: string;
}

export interface Invoice {
  id: string;
  projectId?: string; // Linked Project
  number: string;
  type: DocumentType;
  clientName: string;
  clientEmail: string;
  date: string;
  dueDate: string;
  items: InvoiceItem[];
  status: InvoiceStatus;
  notes?: string;
  total: number;
  emailSentAt?: string; // Track when the quote was sent for validity logic

  // Financial & Config Fields
  quoteMode?: 'COMPANY' | 'INDIVIDUAL';
  docLanguage?: string;
  currency?: string;
  taxRate?: number;
  discount?: number;
  depositPercentage?: number;
  progressPaymentPercentage?: number;
  acceptancePaymentPercentage?: number;
}

export interface UserProfile {
  companyName: string;
  contactName: string;
  address: string;
  email: string;
  phone: string;
  taxId: string;
  depositPercentage: number;
  secondPaymentPercentage: number;
  acceptancePaymentPercentage?: number;
  logo?: string; // Base64 string for logo image
  signature?: string; // Base64 string for signature image
  defaultTerms?: string;
}

export interface PriceItem {
  merchant: string;
  title: string;
  price: string;
  url: string;
}

export interface CostBreakdown {
  materials: { low: number; high: number };
  labor: { low: number; high: number };
  equipment: { low: number; high: number };
  overhead: { low: number; high: number };
}

export interface PriceCheckResult {
  productName: string; // Project Title
  currency: string;
  valuation: {
    min: number;
    max: number;
    avg: number;
  };
  breakdown?: CostBreakdown; // Detailed cost structure
  marketTrend: 'High Demand' | 'Stable' | 'Low Demand' | 'Unknown';
  analysis: string; // Scope of Work
  detailedAnalysis?: {
    methodology: string; // Construction Method
    precautions: string; // Safety/Precautions
    routine: string;     // Routine Details
  };
  listings: PriceItem[]; // Material sources or contractor references
  sources: Array<{
    title: string;
    uri: string;
  }>;
}

export type ClientStatus = 'ACTIVE' | 'ARCHIVED';

export interface Client {
  id: string;
  status: ClientStatus;
  name: string;
  email: string;
  phone: string;
  address: string;
  taxId: string;
  notes: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:MM
  description?: string;
  reminderMinutes?: number; // Minutes before event
  notified?: boolean;
}